async function loadNotes(){
  const res = await fetch('notes.json');
  const list = document.getElementById('notes');
  list.innerHTML='';
  const notes = await res.json();
  notes.forEach(n=>{
    const li=document.createElement('li');
    li.textContent=n.text;
    list.appendChild(li);
  });
}

async function saveNote(){
  const text=document.getElementById('note').value.trim();
  if(!text) return;
  await fetch('https://your-worker-endpoint', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ text })
  });
  document.getElementById('note').value='';
  setTimeout(loadNotes,1500);
}

document.getElementById('save').onclick = saveNote;
loadNotes();
