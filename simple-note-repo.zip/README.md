# Simple Note  
Minimalistická poznámková aplikace ukládající data pomocí **GitHub Actions**.

## Struktura
- root.html — hlavní stránka
- notes.json — uložené poznámky
- .github/workflows/save-note.yml — workflow, které aktualizuje poznámky

## Nasazení
Stačí nahrát repozitář na GitHub:
https://github.com/RuzickaHub/simple-note
